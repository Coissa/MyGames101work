#include <iostream>
#include <vector>

#include "CGL/vector2D.h"

#include "mass.h"
#include "rope.h"
#include "spring.h"

namespace CGL {

    Rope::Rope(Vector2D start, Vector2D end, int num_nodes, float node_mass, float k, vector<int> pinned_nodes)
    {
        // TODO (Part 1): Create a rope starting at `start`, ending at `end`, and containing `num_nodes` nodes.
        Vector2D step = (end - start) / (num_nodes - 1);
//        Comment-in this part when you implement the constructor
        for (int i = 0; i < num_nodes; i++) {
            Mass* newmass = new Mass(start + i * step, node_mass, false);
            masses.push_back(newmass);
            if (i > 0) {
                Spring* newspring = new Spring(masses[i - 1], masses[i], k);
                springs.push_back(newspring);
            }
        }
        for (auto& i : pinned_nodes) {
            masses[i]->pinned = true;
        }
    }

    void Rope::simulateEuler(float delta_t, Vector2D gravity)
    {
        for (auto &s : springs)
        {
            // TODO (Part 2): Use Hooke's law to calculate the force on a node
            auto a = s->m1;
            auto b = s->m2;
            auto k = s->k;
            auto len = s->rest_length;
            auto f = k * (b->position - a->position) / (b->position - a->position).norm() * ((b->position - a->position).norm() - len);
            a->forces += f;
            b->forces += -f;
        }

        for (auto &m : masses)
        {
            if (!m->pinned)
            {
                auto temp = m->position;
                // TODO (Part 2): Add the force due to gravity, then compute the new velocity and position
                
                auto a = m->forces / m->mass + gravity - 0.0005 * m->velocity / m->mass;
                //m->position += m->velocity * delta_t;
                m->velocity += a * delta_t;
                
                m->position += m->velocity * delta_t;
                //m->last_position = temp;
            }

            // Reset all forces on each mass
            m->forces = Vector2D(0, 0);
        }
    }

    void Rope::simulateVerlet(float delta_t, Vector2D gravity)
    {
        for (auto &s : springs)
        {
            // TODO (Part 3): Simulate one timestep of the rope using explicit Verlet （solving constraints)
            auto a = s->m1;
            auto b = s->m2;
            auto k = s->k;
            auto len = s->rest_length;
            auto f = k * (b->position - a->position) / (b->position - a->position).norm() * ((b->position - a->position).norm() - len);
            a->forces += f;
            b->forces += -f;
        }

        for (auto &m : masses)
        {
            if (!m->pinned)
            {
                Vector2D temp = m->position;
                // TODO (Part 2): Add the force due to gravity, then compute the new velocity and position
                auto a = m->forces / m->mass + gravity;
                
                //m->position = 2 * m->position - m->last_position + a * delta_t * delta_t;
                // TODO (Part 2): Add global damping
                m->position = temp + (1 - 0.0005) * (temp - m->last_position) + a * delta_t * delta_t;
                // TODO (Part 3.1): Set the new position of the rope mass
                m->last_position = temp;
                // TODO (Part 4): Add global Verlet damping
            }
            m->forces = Vector2D(0, 0);
        }
        
    }
}
